﻿string respuestaNombre;

Console.Write("Dime tu nombre: ");
respuestaNombre = Console.ReadLine();
Console.WriteLine("Tu nombre es: " + respuestaNombre);
